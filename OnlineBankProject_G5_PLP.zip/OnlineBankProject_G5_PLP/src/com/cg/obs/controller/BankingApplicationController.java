package com.cg.obs.controller;


import java.sql.Date;

import java.util.List;


import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.servlet.ModelAndView;
import com.cg.obs.bean.ServiceTracker;
import com.cg.obs.bean.Transactions;
import com.cg.obs.bean.Users;
import com.cg.obs.service.IUserService;



@Controller
public class BankingApplicationController {

	
	@Autowired
	IUserService userService;
	
	public BankingApplicationController() {
		// TODO Auto-generated constructor stub
	}

	public IUserService getUserService() {
		return userService;
	}

	public void setUserService(IUserService userService) {
		this.userService = userService;
	}

	public BankingApplicationController(IUserService userService) {
		super();
		this.userService = userService;
	}
	
	
	@RequestMapping("Login")
	public String getLoginPage(@RequestParam("username") int userId,
			@RequestParam("password") String password,Model model,HttpSession session){
		
		
		System.out.println(userId+" "+password);
		Users user=userService.getUser(userId);
		System.out.println(user);
		if(user!=null)
		{
			
			
		if(password.equalsIgnoreCase(user.getLoginPassword()))
		{
			System.out.println("user login success");
		      //model.addAttribute("accountno", user.getAccountId());
		session.setAttribute("accountno", user.getAccountId());
		session.setAttribute("user_Id", userId);
			return "index";
		}
		
		
	}
		model.addAttribute("errMsg", "Login error");
			return "pages/ErrorPage";
			
		
	
	}
	
	@RequestMapping("GetMiniTransactions")
	public String getMiniTransactionPage(Model model,HttpSession session){
		
		System.out.println(session.getAttribute("accountno"));
		Long accountno=(Long)session.getAttribute("accountno");
		//System.out.println(accid);
		//Long accountno=Long.parseLong(accid);
		List<Transactions> miniTransList=userService.getMiniTransactions(accountno);
		System.out.println(miniTransList);
		model.addAttribute("miniTrasactionList",miniTransList);
		
		return "pages/MiniTransactions";
	}
	
	@RequestMapping("GetDetailedTransactions")
	public String getDetailedTransactionsPage(@RequestParam("fromDate") Date fromDate,@RequestParam("toDate") Date toDate,Model model,HttpSession session) {
		
		System.out.println(session.getAttribute("accountno"));
		Long accountno=(Long)session.getAttribute("accountno");
		List<Transactions> detailedTransactionList=userService.getDetailedTransactions(accountno, fromDate, toDate);
		model.addAttribute("detailedTransactionList",detailedTransactionList);
		return "pages/DetailedTransactions";
	}

	@RequestMapping("UpdateProfile")
	public void  getUpdateProfilePage(Model model)
	{
		
	}
	
	
	
	
	@RequestMapping("trackRequest")
	public ModelAndView processGetServiceForm(@RequestParam("requestId")int requestid,Model model)
	{

		System.out.println(requestid);
		System.out.println("2Track");
		ServiceTracker tracker= null;
		try 
		{
			System.out.println("inTry");
			tracker=userService.getRequestedServiceList(requestid);
			System.out.println(tracker);
			return new ModelAndView("pages/ShowServiceTrack","tracker",tracker);
		
		} 
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
			return new ModelAndView("pages/ErrorPage","errMsg",
					"Could not retrieve the data. Reason : "+e.getMessage());

		}
	}
	
	

	
	
	@RequestMapping(value="processChqBookRqstExist", method=RequestMethod.POST)
	public String processAddChqBookRqst(@Valid ServiceTracker tracker, BindingResult result, Model model,HttpSession serviceIdsession)
	{
		
		System.out.println("start");
		try
		{
		Long accountno=(Long)serviceIdsession.getAttribute("accountno");
		System.out.println(accountno);
		int serviceid=userService.isCheckBookRequestExist(accountno);
		
		
		if(serviceid==0)
		{
		System.out.println(accountno);
		
			serviceIdsession.setAttribute("serviceId", serviceid);
		String desc = "Cheque Book request";
		System.out.println(desc);
	
		long millis = System.currentTimeMillis();
		java.sql.Date date = new java.sql.Date(millis);

		System.out.println(date);
		// String status=(String)session.getAttribute("Processing");
		String status = "proccessing";

		tracker = new ServiceTracker();

		tracker.setService_Description(desc);
		tracker.setAccount_ID(accountno);
		tracker.setService_Raised_Date(date);
		tracker.setService_Status(status);

		System.out.println(tracker);

		int id = userService.requestService(tracker);

		System.out.println("in ctrl id:" + id);

		model.addAttribute("tracker", id);
		System.out.println(tracker);

		return "pages/ChqBookRequestSuccess";
		}
		else
		{
			model.addAttribute("serviceId", serviceid);
			return "pages/ChqBookRqstExist";
		}
		}
		catch(Exception e)
		{
			e.getMessage();
			model.addAttribute("errMsg", "Something went wrong while adding customer reason " + e.getMessage()) ;
			return "pages/ErrorPage" ;
		}
		
	}
	
	
	@RequestMapping("changePassword")
	public String changePassword(@RequestParam("oldPass")String oldPass,
			@RequestParam("newPass")String newPass ,
			@RequestParam("confirmPass")String confirmPass,
			HttpSession session ,
			Model model)
	{
	System.out.println("in controller");
	
	int id = (int) session.getAttribute("user_Id");
	Users users = null;
	try
	{
		users = userService.getUser(id);
		System.out.println("in try");
		if(oldPass.equalsIgnoreCase(users.getLoginPassword()))
		{
			System.out.println("valid password");
		if (newPass.equals(confirmPass)) {
			System.out.println("equals password");
			users.setLoginPassword(confirmPass);
			
			userService.changePassword(users);

			System.out.println("confirm");
			return "pages/ChangePasswordSuccess";

		} else {
			return "pages/ErrorPage";
		}
		}
		else
		{
			return "pages/ErrorPage";
		}
		}
	catch(Exception e)
	{
		e.printStackTrace();
		model.addAttribute("errMsg", "Something went wrong while adding customer reason " + e.getMessage()) ;
		return "ErrorPage" ;
	}
}
	
}

	

